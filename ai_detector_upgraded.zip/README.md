# 🤖 AI Detector (Upgraded)

This app uses simple computer vision checks to estimate whether an image is **AI-generated** or **real camera-captured**.

### Features
- Sharpness / texture check
- Color distribution check
- Metadata (EXIF) check
- Confidence score
- Streamlit UI with green/red verdicts

### Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

### Deploy to Streamlit Cloud
1. Push these files to a GitHub repo.
2. Go to [share.streamlit.io](https://share.streamlit.io).
3. Deploy using `app.py` as the main file.
